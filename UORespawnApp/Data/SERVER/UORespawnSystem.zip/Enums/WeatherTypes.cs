namespace Server.Custom.UORespawnSystem.Enums
{
    internal enum WeatherTypes
    {
        None,
        Rain,
        Snow,
        Storm,
        Blizzard
    }
}
