namespace Server.Custom.UORespawnSystem.Enums
{
    internal enum TimeNames
    {
        None,
        Witching_Hour,
        Middle_of_Night,
        Early_Morning,
        Late_Morning,
        Noon,
        Afternoon,
        Early_Evening,
        Late_at_Night
    }
}
