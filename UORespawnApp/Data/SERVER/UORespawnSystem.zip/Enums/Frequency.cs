namespace Server.Custom.UORespawnSystem.Enums
{
    internal enum Frequency
    {
        Water,
        Weather,
        Timed,
        Common,
        UnCommon,
        Rare
    }
}
